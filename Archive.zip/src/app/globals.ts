import { Item } from './item';

export class Globals {
    public static currentUser: string = null;
    public static item: Item;
}