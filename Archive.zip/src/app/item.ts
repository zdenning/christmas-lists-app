export interface Item {
    name: string;
    description?: string;
    bought?: boolean;
}