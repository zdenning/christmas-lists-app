import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from "@angular/common/http";
import { Observable, of } from 'rxjs';
import { User } from './user';
import { Globals } from './globals';
import { Item } from './item';
import { map, catchError } from 'rxjs/operators';
import { Config } from 'protractor';
import { __await } from 'tslib';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private host = 'http://ec2-18-206-61-140.compute-1.amazonaws.com:8080/v1';
  private userPost = '/user';
  private allUsersGet = '/user/all';
  private listGet = '/list';
  private loginGet = '/user/login';

  constructor(private http: HttpClient) { }

  addUser(user: User): Observable<User> {
      this.setCurrentUser(user.username);
      return this.http.post<User>(this.host + this.userPost, user);
  }

  async getUsers() {
    return await this.http.get<User[]>(this.host + this.allUsersGet).toPromise();
  }

  getList(usrname: string): Observable<Item[]> {
    return this.http.get<Item[]>(this.host + this.listGet, {
      params: {
        username: usrname
      }
    });
  }

  getCurrentUser(): string {
    return Globals.currentUser;
  }
 
  setCurrentUser(username: string): void {
    Globals.currentUser = username;
    localStorage.setItem("currentUser", Globals.currentUser);
  }

  login(username: string, password: string): Observable<any> {
    return this.http.get(this.host + this.loginGet, {
      params: {
        username: username,
        password: password
      },
      observe: 'response'
    });
  }

}

  

